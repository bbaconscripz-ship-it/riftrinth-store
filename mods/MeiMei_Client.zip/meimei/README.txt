MEIMEI CLIENT - hand menu mod for Orion Drift (Quest)
=====================================================

FIRST TIME
  Gate lock bypass build: verification UI cleared and device-check URLs
  redirected so the menu should open without Discord linking.
  Click the LEFT thumbstick to open the menu.

LOADING SCREEN
  The first time the menu unlocks each session it pops up in front of you and
  downloads the addons the MeiMei admin picked on meimei-gate (plus the ones you
  added yourself), with a progress bar. It closes on its own when done.

Open / close the menu: click the LEFT thumbstick.
The menu floats above your left hand, upright in whatever gravity you're in
(including the station ring), facing you. While it is open a white laser runs
from your RIGHT hand to the menu with a white ball where it hits. The button
under the ball lights up - squeeze RIGHT GRIP (or pull the right trigger) to
press it.
(green = on, red = off, blue = action)

The tabs down the left side: Move, World, Players, Search, Fun, Extra, Addons, Term, Menu,
then one tab for every addon you have loaded. The bottom button, More, flips to the next
page of tabs.

MOVE
  R Trigger: Off / Hand Dash / Head Dash / Fly (hold) / Aim Teleport / Place Platform / Backflip
      tap to switch what the right trigger does
      - Hand Dash:    one push per trigger press, where your right hand points
      - Head Dash:    one push per trigger press, where you are looking
      - Fly (hold):   hold the trigger to fly where your right hand points
      - Aim Teleport: point your hand (up to 50 m) and press to land there
      - Place Platform: drops a 1.5 m platform at your right hand to stand on
      - Backflip:     does a full backflip (same motion as the Backflip mod)
      Dash/fly directions use the game's own hand and head tracking, like the
      Dash Hand / Dash Head Combat mods, and work in combat.
  [-] Dash 20 m/s [+]     dash speed, 5..100 in steps of 5
  [-] Fly 15 m/s [+]      fly speed
  [-] Rocket 12 m/s [+]   rocket strength
  Rocket (R stick)        click the right thumbstick to launch upward
  Hover                   freezes you in the air (pauses while flying)
  Zero-G                  turns your gravity off
  Inf Boost               keeps your boost tank full

WORLD
  12 m/s @ x, y, z        live speed and your position in metres
  Save Slot 1-3 / Go To Slot 1-3   save spots and teleport back to them
  Stop Moving / Up 10 m / Down 10 m
  Mute All                mutes everyone's voice for you

PLAYERS
  [<] 2/6 Name [>]        pick a player (press > first to load the list)
  Teleport To Player      lands you right next to them
  Refresh Player List

SEARCH
  The menu moves in front of your face, with a keyboard below it tilted up
  towards you. Type part of a name (not case-sensitive); the first 3 matches
  show up. Tap "Teleport to <name>" to go to them.
  CAPS, SPACE, <- (backspace), CLR (clear), ENTER (runs a terminal command).
  Pick another tab to put the menu back on your hand.

TERM (terminal)
  Same keyboard. Type a command and press ENTER (or Run):
    help                      list of commands
    tp <name>                 teleport to a player
    speed dash|fly|rocket <n> set a speed in m/s
    noclip, hover, zerog, flip, frozone, gripplats, stop, up10 ...
                              any mod's name toggles / runs it
    mods                      what's switched on
    addon add <id or link>    download an addon (a name from the gate's catalog,
                              or a link to an addon zip); it loads straight away
                              and again every time you start the game
    addon list | addon remove <id> | addon reload
    catalog, motd, whoami, ping   answered by meimei-gate

ADDONS
  Addons are extra content (models, sounds, whole events) downloaded from
  meimei-gate instead of living in the OBB. Up to 12, four a page (< > to flip).
  [name >] [Remove]       the name opens that addon's own tab; Remove unloads it
  Reload Startup Addons

AN ADDON'S OWN TAB (e.g. "travis")
  While it is open, point away from the menu and pull the RIGHT TRIGGER to place
  the addon where you point. Its buttons are the addon's own, for example travis:
  Restart Show, Stop Show, Prev / Next Song, Volume - / +, Mini Size, Loop Show.

FUN
  Backflip! / Noclip      flip once / walk and fly through walls
                          (with Noclip on you stop as soon as you let go of fly,
                          dash, rocket and your thrusters)
  Driftium / Joules / Tech Pts Rain   the reward shower effect (visual only, no currency)
  Platform Under Me / Clear Platforms   pink platforms only you can see and stand on
  Grip Platforms          hold either GRIP: a small slab appears under that hand to
                          push off mid-air; let go and it's gone
  Frozone                 lays ice under your feet as you move (melts after 6 s)

EXTRA (the game's own settings)
  Hide HUD / Hide Spectators / Stick Turn Off
  Mod List                the list of mods that are on, under the game's ping/speed HUD
  START RECORDING / STOP & WATCH   one button: press to record, press again to stop;
                                   it saves for 1.5 s, then plays what you just recorded
  Watch Last Replay                plays the game's most recent replay

MENU
  Pin Menu                leaves the menu floating where it is
  Reset Speeds / Turn Everything Off / Close Menu
  Start/Stop Timer, Reset Timer   stopwatch for timing runs

Everything runs on your headset only. Nothing here changes other players,
your inventory, or the server. Movement cheats in public lobbies can still get
an account flagged - test in private sessions.

Only one BP_VRPawn mod works at a time; disable other pawn mods in Patchbay.
