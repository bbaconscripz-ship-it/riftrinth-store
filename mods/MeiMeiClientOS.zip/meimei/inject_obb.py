#!/usr/bin/env python3
import io, os, sys, zipfile, glob

zipfile.ZIP64_LIMIT = 0xFFFFFFF0       
PATCH_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'patch')
PAK_DIR = 'A2/Content/Paks/'
PAD_NAME = 'A2/Content/pad.bin'
DROP_STAGES = ['A2/Content/Scripts/Cameras/Documentation/',
               'A2/Content/UI/Spectator/',
               'A2/Content/Replays/']

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    src = sys.argv[1]
    out = sys.argv[2] if len(sys.argv) > 2 else os.path.join(os.path.dirname(os.path.abspath(src)), 'patched_' + os.path.basename(src))
    if os.path.abspath(src) == os.path.abspath(out):
        sys.exit('Output must differ from input.')
    target = os.path.getsize(src)
    zs = zipfile.ZipFile(src)
    names = {i.filename for i in zs.infolist()}
    if PAK_DIR + 'A2-Android_ASTC.utoc' not in names:
        sys.exit('This does not look like the Orion Drift OBB (A2-Android_ASTC.utoc missing).')
    patch = [(p, PAK_DIR + os.path.basename(p)) for p in sorted(glob.glob(os.path.join(PATCH_DIR, 'A2-Android_ASTC_*P.*')))]
    if any(n in names for _, n in patch):
        sys.exit('This OBB already contains the patch. Use a pristine OBB.')
    assert len(patch) == 3, 'patch files missing next to the script'
    psize = sum(os.path.getsize(p) for p, _ in patch)
    ov = lambda n: 30 + 46 + 2 * len(n)           # local + central header cost of an entry
    need = psize + sum(ov(n) for _, n in patch) + ov(PAD_NAME)
    drop_prefixes = []
    freed = 0
    for stage in DROP_STAGES:
        if freed >= need:
            break
        drop_prefixes.append(stage)
        freed = sum(i.file_size + ov(i.filename) for i in zs.infolist() if i.filename.startswith(tuple(drop_prefixes)))
    if freed < need:
        sys.exit('Not enough removable space for the patch.')
    drop = lambda n: n.startswith(tuple(drop_prefixes))
    print('Removing:', ', '.join(drop_prefixes), '(%.1f MB)' % (freed / 1e6))

    def build(pad):
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_STORED, allowZip64=True) as zo:
            zo.comment = zs.comment
            def add(name, reader, size, dt):
                zi = zipfile.ZipInfo(name, dt); zi.compress_type = 0; zi.file_size = size
                with zo.open(zi, 'w') as o:
                    while True:
                        b = reader.read(1 << 24)
                        if not b: break
                        o.write(b)
            for i in zs.infolist():
                if drop(i.filename): continue
                with zs.open(i) as s: add(i.filename, s, i.file_size, i.date_time)
            for p, n in patch:
                with open(p, 'rb') as s: add(n, s, os.path.getsize(p), (2026, 10, 17, 0, 0, 0))
            if pad is not None:
                add(PAD_NAME, io.BytesIO(b'\0' * pad), pad, (2026, 10, 17, 0, 0, 0))
    print('Building (this copies ~3 GB)...')
    build(None)
    pad = target - os.path.getsize(out) - ov(PAD_NAME)
    build(pad)
    delta = os.path.getsize(out) - target
    if delta:
        build(pad - delta)
    assert os.path.getsize(out) == target, 'size mismatch'
    bad = zipfile.ZipFile(out).testzip()
    assert bad is None, 'CRC error in ' + str(bad)
    print('Done: %s (%d bytes, identical size to input, CRCs OK)' % (out, target))

if __name__ == '__main__':
    main()
