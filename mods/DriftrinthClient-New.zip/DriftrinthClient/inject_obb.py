#!/usr/bin/env python3
"""Inject the Driftrinth Client patch into a clean Orion Drift OBB, keeping its exact size.

usage: inject_obb.py <clean.obb> [patched.obb] [--dry-run]
"""
import argparse
import os
import shutil
import sys
import zipfile

zipfile.ZIP64_LIMIT = 0xFFFFFFF0  # keep entries under 4 GB free of zip64 extras, as the game's OBB is

HERE = os.path.dirname(os.path.abspath(__file__))
PAK_DIR = 'A2/Content/Paks/'
BASE_TOC = PAK_DIR + 'A2-Android_ASTC.utoc'
PATCH_STEM = 'A2-Android_ASTC_DriftrinthClient_P'
PATCH_EXTS = ('.utoc', '.ucas', '.pak')
PAD_NAME = 'A2/Content/pad.bin'
DROP_STAGES = ['A2/Content/Scripts/Cameras/Documentation/',
               'A2/Content/UI/Spectator/',
               'A2/Content/Replays/']
WARN_STAGES = {'A2/Content/UI/Spectator/': 'spectator UI', 'A2/Content/Replays/': 'replays'}
PATCH_DATE = (2026, 1, 1, 0, 0, 0)
CHUNK = 1 << 24


def entry_cost(name):
    return 30 + 46 + 2 * len(name.encode())


def plan(zs, patch_files):
    """Returns the drop prefixes that free enough room for the patch and padding entry."""
    need = sum(os.path.getsize(p) + entry_cost(n) for p, n in patch_files) + entry_cost(PAD_NAME)
    prefixes, freed = [], 0
    for stage in DROP_STAGES:
        if freed >= need:
            break
        prefixes.append(stage)
        freed = sum(i.file_size + entry_cost(i.filename) for i in zs.infolist()
                    if i.filename.startswith(tuple(prefixes)))
    if freed < need:
        sys.exit('Not enough removable data: need %d bytes, can free %d.' % (need, freed))
    return prefixes, need, freed


def add_entry(zo, name, reader, size, when):
    info = zipfile.ZipInfo(name, when)
    info.compress_type = zipfile.ZIP_STORED
    info.file_size = size
    with zo.open(info, 'w') as out:
        shutil.copyfileobj(reader, out, CHUNK)


class Zeros:
    def __init__(self, n):
        self.left = n

    def read(self, n):
        n = min(n, self.left)
        self.left -= n
        return b'\0' * n


def add_padding(out, target):
    """Appends the padding entry so the file is exactly `target` bytes."""
    with zipfile.ZipFile(out) as z:
        start_dir = z.start_dir
    with open(out, 'rb') as f:
        f.seek(start_dir)
        tail = f.read()
    base = start_dir + len(tail)
    pad = target - base - entry_cost(PAD_NAME)
    for _ in range(4):  # zip64 records can shift the total by a few bytes, so converge
        if pad < 0:
            sys.exit('Padding went negative; output is larger than the input.')
        with zipfile.ZipFile(out, 'a', allowZip64=True) as zo:
            add_entry(zo, PAD_NAME, Zeros(pad), pad, PATCH_DATE)
        delta = os.path.getsize(out) - target
        if delta == 0:
            return pad
        with open(out, 'r+b') as f:  # undo: restore the unpadded end of the archive
            f.seek(start_dir)
            f.write(tail)
            f.truncate()
        pad -= delta
    sys.exit('Could not reach the exact target size.')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('obb')
    ap.add_argument('out', nargs='?')
    ap.add_argument('--dry-run', action='store_true', help='show what would change, write nothing')
    ap.add_argument('--patch-dir', default=os.path.join(HERE, 'patch'))
    args = ap.parse_args()

    src = os.path.abspath(args.obb)
    out = os.path.abspath(args.out or os.path.join(os.path.dirname(src), 'patched_' + os.path.basename(src)))
    if src == out:
        sys.exit('Output must differ from input.')
    if os.path.exists(out) and not args.dry_run:
        sys.exit('Output already exists: ' + out)

    patch_files = []
    for ext in PATCH_EXTS:
        path = os.path.join(args.patch_dir, PATCH_STEM + ext)
        if not os.path.isfile(path):
            sys.exit('Missing patch file: ' + path)
        patch_files.append((path, PAK_DIR + PATCH_STEM + ext))

    target = os.path.getsize(src)
    with zipfile.ZipFile(src) as zs:
        names = {i.filename for i in zs.infolist()}
        if BASE_TOC not in names:
            sys.exit('This does not look like the Orion Drift OBB (%s missing).' % BASE_TOC)
        foreign = [n for n in names if n.startswith(PAK_DIR + 'A2-Android_ASTC_') and n.rsplit('.', 1)[0].endswith('_P')]
        if foreign or PAD_NAME in names:
            sys.exit('This OBB is already patched (%s). Use a clean OBB.' % (foreign[0] if foreign else PAD_NAME))

        prefixes, need, freed = plan(zs, patch_files)
        print('Patch and overhead: %.1f MB; removing %.1f MB:' % (need / 1e6, freed / 1e6))
        for p in prefixes:
            print('  ' + p)
            if p in WARN_STAGES:
                print('  WARNING: this may affect ' + WARN_STAGES[p])
        if args.dry_run:
            print('Dry run: nothing written.')
            return
        if shutil.disk_usage(os.path.dirname(out)).free < target:
            sys.exit('Not enough free disk for the output.')

        drop = tuple(prefixes)
        print('Building %s ...' % out)
        with zipfile.ZipFile(out, 'w', zipfile.ZIP_STORED, allowZip64=True) as zo:
            zo.comment = zs.comment
            for info in zs.infolist():
                if info.filename.startswith(drop):
                    continue
                with zs.open(info) as reader:
                    add_entry(zo, info.filename, reader, info.file_size, info.date_time)
            for path, name in patch_files:
                with open(path, 'rb') as reader:
                    add_entry(zo, name, reader, os.path.getsize(path), PATCH_DATE)

    pad = add_padding(out, target)
    print('Verifying CRCs ...')
    with zipfile.ZipFile(out) as z:
        bad = z.testzip()
    if bad is not None:
        sys.exit('CRC error in ' + bad)
    if os.path.getsize(out) != target:
        sys.exit('Size mismatch.')
    print('Done: %s (%d bytes, %d padding, same size as input, CRCs OK)' % (out, target, pad))


if __name__ == '__main__':
    main()
