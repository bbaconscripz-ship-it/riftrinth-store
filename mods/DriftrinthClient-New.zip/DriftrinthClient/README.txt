DRIFTRINTH CLIENT - hand menu mod for Orion Drift (Quest)
=========================================================

No account, link code or sign-in. The menu works as soon as the game loads.
This is an unofficial, open-source fan project and isn't affiliated with Another Axiom.
Source code: https://github.com/YOUR_NAME/DriftrinthClient

INSTALL
  You need Python 3, adb and a copy of your clean game OBB.
  1. Back up your OBB. Keep the clean copy.
  2. Copy the OBB from the headset:
       adb pull /sdcard/Android/obb/<game package>/<obb file> clean.obb
  3. Run:
       python inject_obb.py clean.obb patched.obb
  4. Push it back under the ORIGINAL file name:
       adb push patched.obb /sdcard/Android/obb/<game package>/<obb file>

  The script removes some game files to keep the OBB the same size and prints which
  ones. Removing spectator or replay files may affect those features.
  Game update: start again from a new clean OBB. The mod may need rebuilding.
  Uninstall: push your clean OBB back, or reinstall the game.

USING IT
  The menu opens by itself once per game launch, floating in front of you. After
  you close it, it opens on your wrist or wherever you pinned it.

  Left stick click     open / close
  Right hand           point at the menu, a cursor appears
  Right trigger        click, hold to drag a slider
  Bottom bar           explains whatever you point at
  Text boxes           click one to bring up the keyboard
  Left Handed          in Settings: swaps the sticks, hands and triggers
  Menu Color           in Settings: pick a color on a color wheel

  Tabs: Move, World, Players, Fun, Toys, Effects, Visuals, Sounds, HUD, Terminal,
  Search, Settings.
  In Terminal, type "help" for commands. Search finds any mod by name.

SOLO ONLY
  Movement mods (fly, dash, noclip, teleport and others) only work when you are the
  only player in the session. They grey out and turn off when anyone else is there,
  and anything you built or spawned is removed. Effects, sounds and sky settings only
  change what you see and hear, so they keep working.
  Using mods online can get you banned.
